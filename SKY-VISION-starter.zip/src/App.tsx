import { useEffect, useMemo, useRef, useState } from 'react'
import maplibregl, { Map as MlMap, Marker } from 'maplibre-gl'
import { Cloud, CloudRain, Wind, Thermometer, Droplets, Gauge, MapPin, LocateFixed, Satellite, Layers3, Search, RefreshCw, Menu, X, Eye, Activity, Compass, Clock3 } from 'lucide-react'

type Weather = {
  temperature_2m?: number; apparent_temperature?: number; relative_humidity_2m?: number;
  precipitation?: number; rain?: number; cloud_cover?: number; pressure_msl?: number;
  wind_speed_10m?: number; wind_direction_10m?: number; wind_gusts_10m?: number;
  weather_code?: number; is_day?: number; time?: string;
}
const START: [number, number] = [30.0444, 31.2357]
const layers = [
  { id: 'cloud', label: 'غطاء السحب', icon: Cloud },
  { id: 'rain', label: 'الأمطار', icon: CloudRain },
  { id: 'wind', label: 'الرياح', icon: Wind },
  { id: 'temp', label: 'الحرارة', icon: Thermometer },
  { id: 'satellite', label: 'القمر الصناعي', icon: Satellite },
] as const

function direction(deg = 0) {
  const dirs = ['شمال', 'شمال شرقي', 'شرق', 'جنوب شرقي', 'جنوب', 'جنوب غربي', 'غرب', 'شمال غربي']
  return dirs[Math.round(deg / 45) % 8]
}
function App() {
  const mapNode = useRef<HTMLDivElement>(null)
  const map = useRef<MlMap | null>(null)
  const marker = useRef<Marker | null>(null)
  const [coords, setCoords] = useState<[number, number]>(START)
  const [weather, setWeather] = useState<Weather | null>(null)
  const [hourly, setHourly] = useState<{time:string; temperature_2m:number; precipitation_probability:number}[]>([])
  const [activeLayer, setActiveLayer] = useState<string>('cloud')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [place, setPlace] = useState('القاهرة، مصر')
  const [mobileOpen, setMobileOpen] = useState(false)
  const [clock, setClock] = useState(new Date())

  async function loadWeather(lat: number, lon: number) {
    setLoading(true); setError('')
    try {
      const url = new URL('https://api.open-meteo.com/v1/forecast')
      url.search = new URLSearchParams({
        latitude: String(lat), longitude: String(lon),
        current: 'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m,weather_code',
        hourly: 'temperature_2m,precipitation_probability,cloud_cover,wind_speed_10m',
        forecast_days: '2', timezone: 'auto'
      }).toString()
      const res = await fetch(url)
      if (!res.ok) throw new Error('تعذر جلب بيانات الطقس من المصدر')
      const data = await res.json()
      setWeather(data.current ?? null)
      const times: string[] = data.hourly?.time ?? []
      const temps: number[] = data.hourly?.temperature_2m ?? []
      const probs: number[] = data.hourly?.precipitation_probability ?? []
      const now = data.current?.time ?? ''
      const start = Math.max(0, times.findIndex(t => t >= now))
      setHourly(times.slice(start, start + 12).map((time, i) => ({
        time, temperature_2m: temps[start + i] ?? 0, precipitation_probability: probs[start + i] ?? 0
      })))
    } catch (e) { setError(e instanceof Error ? e.message : 'حدث خطأ غير معروف') }
    finally { setLoading(false) }
  }

  useEffect(() => {
    const timer = window.setInterval(() => setClock(new Date()), 1000)
    return () => window.clearInterval(timer)
  }, [])

  useEffect(() => {
    if (!mapNode.current || map.current) return
    const m = new maplibregl.Map({
      container: mapNode.current,
      center: [START[1], START[0]], zoom: 5,
      style: {
        version: 8,
        sources: { carto: { type: 'raster', tiles: ['https://basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png'], tileSize: 256, attribution: '&copy; OpenStreetMap &copy; CARTO' } },
        layers: [{ id: 'dark-base', type: 'raster', source: 'carto', paint: { 'raster-opacity': 0.92 } }]
      },
      attributionControl: false
    })
    m.addControl(new maplibregl.NavigationControl({ showCompass: true }), 'top-left')
    m.addControl(new maplibregl.AttributionControl({ compact: true }), 'bottom-left')
    m.on('click', (ev) => {
      const next: [number, number] = [ev.lngLat.lat, ev.lngLat.lng]
      setCoords(next); setPlace(`${next[0].toFixed(3)}, ${next[1].toFixed(3)}`)
      marker.current?.remove()
      marker.current = new maplibregl.Marker({ color: '#50c8ff' }).setLngLat([next[1], next[0]]).addTo(m)
      loadWeather(next[0], next[1])
    })
    map.current = m
    return () => { m.remove(); map.current = null }
  }, [])

  useEffect(() => { loadWeather(coords[0], coords[1]) }, [])

  const stats = useMemo(() => [
    { label: 'درجة الحرارة', value: weather?.temperature_2m, unit: '°', icon: Thermometer },
    { label: 'المحسوسة', value: weather?.apparent_temperature, unit: '°', icon: Thermometer },
    { label: 'الرطوبة', value: weather?.relative_humidity_2m, unit: '%', icon: Droplets },
    { label: 'غطاء السحب', value: weather?.cloud_cover, unit: '%', icon: Cloud },
    { label: 'سرعة الرياح', value: weather?.wind_speed_10m, unit: ' كم/س', icon: Wind },
    { label: 'هبات الرياح', value: weather?.wind_gusts_10m, unit: ' كم/س', icon: Activity },
    { label: 'الضغط الجوي', value: weather?.pressure_msl, unit: ' hPa', icon: Gauge },
    { label: 'الأمطار', value: weather?.precipitation, unit: ' مم', icon: CloudRain },
  ], [weather])

  function locate() {
    if (!navigator.geolocation) { setError('المتصفح لا يدعم تحديد الموقع'); return }
    navigator.geolocation.getCurrentPosition(pos => {
      const lat = pos.coords.latitude, lon = pos.coords.longitude
      setCoords([lat, lon]); setPlace(`${lat.toFixed(3)}, ${lon.toFixed(3)}`)
      map.current?.flyTo({ center: [lon, lat], zoom: 8, essential: true })
      marker.current?.remove()
      if (map.current) marker.current = new maplibregl.Marker({ color: '#50c8ff' }).setLngLat([lon, lat]).addTo(map.current)
      loadWeather(lat, lon)
    }, () => setError('لم نتمكن من تحديد موقعك. تحقق من إذن الموقع.'))
  }

  return <div className="app-shell">
    <header className="topbar">
      <button className="icon-btn mobile-menu" onClick={() => setMobileOpen(!mobileOpen)} aria-label="القائمة">{mobileOpen ? <X/> : <Menu/>}</button>
      <div className="brand"><div className="brand-mark"><Activity size={21}/></div><div><b>SKY <span>VISION</span></b><small>مركز الرصد الجوي</small></div></div>
      <div className="top-location"><MapPin size={15}/><span>{place}</span></div>
      <div className="top-right"><span className="live-dot"></span><span>بيانات الطقس المباشرة</span><span className="clock">{clock.toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}</span><button className="icon-btn" onClick={() => loadWeather(coords[0],coords[1])} title="تحديث"><RefreshCw size={17}/></button></div>
    </header>
    <div className="layout">
      <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
        <div className="side-heading">طبقات الخريطة <Layers3 size={16}/></div>
        {layers.map(layer => { const Icon = layer.icon; return <button key={layer.id} className={`layer-btn ${activeLayer===layer.id?'selected':''}`} onClick={() => setActiveLayer(layer.id)}><Icon size={18}/><span>{layer.label}</span><span className="layer-state">{activeLayer===layer.id?'●':'○'}</span></button> })}
        <div className="side-divider"/>
        <button className="locate-btn" onClick={locate}><LocateFixed size={17}/> موقعي الحالي</button>
        <div className="side-note"><Satellite size={17}/><div><b>طبقات الرصد</b><p>واجهة اختيار الطبقات جاهزة. سيتم توصيل صور الأقمار والرادار الفعلية في المرحلة التالية.</p></div></div>
        <div className="source-tag">مصدر البيانات: Open-Meteo</div>
      </aside>
      <main className="main-content">
        <section className="hero-row"><div><div className="eyebrow"><span className="live-dot"/> لوحة المراقبة الجوية</div><h1>حالة الغلاف الجوي</h1><p>اختر أي نقطة على الخريطة لعرض بيانات الطقس الخاصة بها.</p></div><div className="coords-box"><Compass size={18}/><div><small>الإحداثيات المحددة</small><b>{coords[0].toFixed(4)}° N · {coords[1].toFixed(4)}° E</b></div></div></section>
        {error && <div className="error-banner">{error}</div>}
        <section className="map-panel">
          <div className="map-overlay-title"><span className="pulse"/> الخريطة التفاعلية <small>اضغط على الخريطة لتحديد موقع</small></div>
          <div ref={mapNode} className="map-canvas"/>
          <div className="map-legend"><span><i className="legend-blue"/> طبقة {layers.find(l=>l.id===activeLayer)?.label}</span><span>خريطة أساس داكنة</span></div>
        </section>
        <section className="section-head"><div><h2>القياسات الجوية</h2><p>أحدث قراءة متاحة للنقطة المحددة</p></div><span className="updated">{loading?'جارٍ التحديث…':weather?.time ? `آخر تحديث ${weather.time.replace('T',' ')}` : 'في انتظار البيانات'}</span></section>
        <section className="stats-grid">
          {stats.map(({label,value,unit,icon:Icon}) => <article className="stat-card" key={label}><div className="stat-icon"><Icon size={18}/></div><div className="stat-label">{label}</div><div className="stat-value">{value == null ? '—' : Math.round(value*10)/10}<small>{value == null ? '' : unit}</small></div></article>)}
        </section>
        <section className="section-head"><div><h2>التوقعات خلال 12 ساعة</h2><p>درجة الحرارة واحتمال هطول الأمطار</p></div><Clock3 size={18}/></section>
        <section className="hourly-row">
          {hourly.map((h,i)=><div className="hour-card" key={h.time}><small>{i===0?'الآن':new Date(h.time).toLocaleTimeString('ar-EG',{hour:'2-digit'})}</small><Thermometer size={17}/><b>{Math.round(h.temperature_2m)}°</b><span className="rain-chance"><CloudRain size={13}/>{h.precipitation_probability}%</span></div>)}
          {!hourly.length && <div className="empty-state">يتم تحميل التوقعات…</div>}
        </section>
        <footer>SKY VISION · البيانات الجوية مقدمة من Open-Meteo · ليست بديلاً عن التحذيرات الرسمية</footer>
      </main>
    </div>
  </div>
}
export default App